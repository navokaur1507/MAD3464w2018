/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day12java;

/**
 *
 * @author macstudent
 */
public class Day12Java {

    /**
     * @param args the command line arguments
     */
    public static < E > void printArray(E[] inputArray) {
        // TODO code application logic here
    // Display array Elements
    for(E element : inputArray) {
        System.out.printf("%s", element);
        
    }
    System.out.println();
    
    
}
    
public static void main(String args[]) {
// create arrays of integer, Double and char
Integer[] intArray = { 1, 2, 3, 4, 5};
Double[] doubleArray = {1.1, 2.2, 3.3, 4.4, };
Character[] charArray = {'H', 'E', 'L', 'l', 'o'};

System.out.println("Array integerArray contains");
printArray(intArray);

System.out.println("\nArray doubleArray contains");
printArray(charArray);
    }
    
}
