/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3classactivity;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day3ClassActivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PersonInfo P = new Person();
        P.readData();
        P.displayData();
        
        EmployeeInfo E = new Employee();
        E.readValues();
        E.displayValues();
        
        Faculity F = new FaculityInfo();
        F.setData();
        F.getData();
    }
    
}

interface PersonInfo {
    String name = "NK";
    int age = 22;
    
    void readData();
    void displayData();
    
}

class Person implements PersonInfo {
    
    @Override
    public void readData(){
        System.out.println(" Name of Person " + name);
        System.out.println("Age of Person" + age);
    }
    
    @Override
    public void displayData(){
        System.out.println(" Name of Person " + name);
        System.out.println("Age of Person" + age);
    }
}

interface EmployeeInfo {
    
       String Type = "FullTime";
       int Salary = 4000;
       void readValues();
       void displayValues();

}
class Employee extends Person implements EmployeeInfo {
    
    @Override
    public void readValues(){
        System.out.println("Type of Employee is FullTime" + Type);
        System.out.println("Salay of Employee" + Salary);
    }

    @Override
    public void displayValues() {
        System.out.println("Type of Employee is FullTime" + Type);
        System.out.println("Salay of Employee" + Salary);
    }
    
}

interface Faculity {
    String course = "Java";
    void setData();
    void getData();
            
}

class FaculityInfo extends Employee implements Faculity {
    
    @Override
    public void setData() {
        System.out.println("Name of Course" + course);
    }
    
    @Override
    public void getData() {
        System.out.println("Name of Course" + course);
    }
    
}