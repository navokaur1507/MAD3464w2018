import java.sql.*;
/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */

/**
 *
 * @author jkp
 */
public class JDBCOperations {
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs = null;
    static String USER = "root";
    static String PASS = "";
    
    
    public static void main(String [] args){
        connectDB();
        selectDB();
        
        insertDB();
        selectDB();
        
        updateDB();
        selectDB();
        
        deleteDB();
        selectDB();
        
        closeDB();
    }
    
    static void connectDB(){
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/MADWinter18", USER, PASS);
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    static void insertDB(){
        try{
            stmt = conn.prepareStatement("INSERT INTO Person VALUES(?,?,?,?)");
            stmt.setInt(1, 102);
            stmt.setString(2, "Sonal");
            stmt.setString(3, "Verma");
            stmt.setInt(4, 23);
            
            
            int nrec = stmt.executeUpdate();
            System.out.println(nrec + " records inserted");
           
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    static void selectDB(){
        try{
            stmt = conn.prepareStatement("SELECT * FROM Person");
            
            //rs = stmt.execute();
            
           rs = stmt.executeQuery();
           
           while(rs.next()){
              
               System.out.println(" ID : " + rs.getInt(1) + 
                       " FirstName : " + rs.getString("FirstName") + 
                       " LastName : " + rs.getString("LastName") + 
                       " Age : " + rs.getInt("Age"));
           }
           
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    static void deleteDB(){
        try{
            stmt = conn.prepareStatement("DELETE FROM Person WHERE Id = ?");
            stmt.setInt(1, 102);
            
            int nrec = stmt.executeUpdate();
            System.out.println(nrec + " records inserted");
           
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    static void updateDB(){
        try{
            stmt = conn.prepareStatement("UPDATE Person SET FirstName = ?, LastName = ?, Age = ? WHERE Id = ?");
            
            stmt.setString(1, "Sona");
            stmt.setString(2, "Verma");
            stmt.setInt(3, 22);
            stmt.setInt(4, 102);
            
            
            int nrec = stmt.executeUpdate();
            System.out.println(nrec + " records inserted");
           
        }
        catch(SQLException e){
            e.printStackTrace();
        }        
    }
    
    static void closeDB(){
            try{
                if (conn!= null){
                    conn.close();
                }
            }
            catch(SQLException e){
                e.printStackTrace();;
            }
        }
}