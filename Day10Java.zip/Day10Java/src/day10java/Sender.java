/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day10java;

import java.util.Random;
/**
 *
 * @author macstudent
 */
public class Sender implements Runnable{
    private Carreer carreer;
    
    Sender(Carreer carreer){
        this.carreer = carreer;
    }

    @Override
    public void run() {
        Random random = new Random();
        String messagesToSend []= {
            "Hello",
            "I hope You are OK",
            "Lets meet for a Lunch",
            "See you at The Keg at 1 o'clock",
            "See You..!"
        };
        
        for (int i=0; i<messagesToSend.length ; i++){
            carreer.sendMessage(messagesToSend[i]);
            try{
                Thread.sleep(1000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        
        carreer.sendMessage("Over n Out");
    }
    
}
