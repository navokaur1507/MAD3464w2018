/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day10java;

import java.util.Random;
/**
 *
 * @author macstudent
 */
public class Reciever implements Runnable{
    private Carreer carreer;
    
    Reciever(Carreer carreer){
        this.carreer = carreer;
    }

    @Override
    public void run() {
        Random random = new Random();
        String message = carreer.receiveMessage();
        
        while(!message.equals("Over n Out")){
            message = carreer.receiveMessage();
            System.out.println("Receing the message");
            
            System.out.format("MESSAGE RECEIVED: %s%n", message);
            
            try{
                Thread.sleep(500);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    }
    
}
