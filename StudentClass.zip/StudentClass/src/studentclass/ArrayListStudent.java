/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentclass;

/**
 *
 * @author macstudent
 */
public class ArrayListStudent {
    
    public static void main(String[] args){
        
        //StudentClass Name = new StudentClass(1,"NAV", 8);
        //StudentClass RollNumber = new StudentClass(2,13, 3);
        //StudentClass percentage = new StudentClass(3,85, 2);
        
        //StudentClass Name = new StudentClass(4,"Jhon", 3);
        //StudentClass RollNumber = new StudentClass(5,15, 4);
        //StudentClass percentage = new StudentClass(6,89, 2);
    }
    
}
