/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentclass;

/**
 *
 * @author macstudent
 */
public class StudentClass {
    
    String Name;
    int RollNumber;
    int percentage;
    
    StudentClass(){
        this.Name = "Unknown";
        this.RollNumber = 0;
        this.percentage = 0;
        
    }
    
    StudentClass(String Name, int RollNumber, int percentage){
        this.Name = Name;
        this.RollNumber = RollNumber;
        this.percentage = percentage;
    }
    
    void setNAme(String Name){
        this.Name = Name;
    }
    String getName(){
        return this.Name;
    }
    
    void setRollNumber(int RollNumber){
        this.RollNumber = RollNumber;
    }

    int getRollNumber(){
        return this.RollNumber;
    }
    
    void setpercentage(int percentage){
        this.percentage = percentage;
    }
    int getpercentage(){
        return this.percentage;
    }
    
    void displayInfo(){
        System.out.println("Name : " + this.Name + "\n RollNumber : " + this.RollNumber + "\n percentage : " + this.percentage);
    }
  
}
